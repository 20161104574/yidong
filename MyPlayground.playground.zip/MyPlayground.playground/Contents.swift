//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var a=1
a=10
var b=2
let c=a+b
